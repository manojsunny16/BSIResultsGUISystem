/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package oop.ica.part2;


import javax.swing.table.AbstractTableModel;
import java.util.ArrayList;

public class StudentMarkTableModel extends AbstractTableModel 
{
    private final ArrayList<StudentMark> studentMarkList;
    private final String[] columnNames;
    
// Constructor to initialize the table model with column names and student mark data
    public StudentMarkTableModel(String[] columnNames, ArrayList<StudentMark> studentMarkList ) 
    {
         this.columnNames = columnNames;
        this.studentMarkList = studentMarkList;
    }

    @Override
    public int getRowCount() 
    {
        return studentMarkList.size();
    }

    @Override
    public int getColumnCount() 
    {
        return columnNames.length;
    }
    
    // Returns the value at a specific row and column in the tabl
    @Override
    public Object getValueAt(int rowIndex, int columnIndex) 
    {
        StudentMark student = studentMarkList.get(rowIndex);
        return switch (columnIndex) 
        {
            case 0 -> student.getFirstName() + " " + student.getSurname();
            case 1 -> student.getId();
            case 2 -> student.getModule();
            case 3 -> student.getMark();
            case 4 -> student.getResult();
            default -> null;
        };
    }

    @Override
    public String getColumnName(int column) 
    {
        return columnNames[column];
    }
    
    // Determines if a cell is editable; only the "Mark" column (index 3) is editable
    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) 
    {
        return columnIndex == 3; // Only "Mark" column is editable
    }

    // Sets the value at a specific cell (used when editing the table)
    @Override
    public void setValueAt(Object aValue, int rowIndex, int columnIndex) 
    {
        StudentMark student = studentMarkList.get(rowIndex);
        if (columnIndex == 3) // Update mark
        { 
            student.setMark((Integer) aValue);
        } 
        else if (columnIndex == 4) // Update result
        { 
            student.setResult((String) aValue);
        }
        fireTableCellUpdated(rowIndex, columnIndex);
    }
}

   

   

    
    

