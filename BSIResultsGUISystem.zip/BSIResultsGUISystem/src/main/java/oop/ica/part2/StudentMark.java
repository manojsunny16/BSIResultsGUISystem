/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package oop.ica.part2;

import java.util.regex.Pattern;

public class StudentMark 
{
    private final String firstName;
    private final String surname;
    private final String id;
    private int mark;
    private final String module;
    private final int passMark;
    private String result;

    public StudentMark(String firstName, String surname, String id, int mark, String module, int passMark) 
    {
        // Validate and set firstName and surname
        if (!isValidName(firstName) || !isValidName(surname)) 
        {
            throw new IllegalArgumentException("First name and surname should not contain spaces or punctuation.");
        }
        this.firstName = firstName;
        this.surname = surname;

        // Validate and set ID
        if (!isValidId(id)) 
        {
            throw new IllegalArgumentException("ID should be a 6-digit number and not start with 0.");
        }
        this.id = id;

        this.mark = mark;
        this.module = module;
        this.passMark = passMark;
        this.result = (mark >= passMark) ? "Pass" : "Fail";
    }

    private boolean isValidName(String name) 
    {
        // Check if the name contains only letters
        return name != null && Pattern.matches("[a-zA-Z]+", name);
    }

    private boolean isValidId(String id) 
    {
        // Check if the ID is a 6-digit number and does not start with 0
        return id != null && id.matches("[1-9][0-9]{5}");
    }
    // Getter methods to retrieve the values of the fields
    public String getFirstName() 
    { 
        return firstName; 
    }
    public String getSurname() 
    { 
        return surname; 
    }
    public String getId() 
    { 
        return id; 
    }
    public int getMark() 
    { 
        return mark; 
    }
    public String getModule() 
    { 
        return module; 
    }
    public int getPassMark() 
    { 
        return passMark; 
    }
    public String getResult() 
    { 
        return result; 
    }

    public void setMark(int mark) 
    { 
        this.mark = mark; 
    }
    public void setResult(String result) 
    { 
        this.result = result; 
    }
}
